<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cook extends Model
{
    //
}
