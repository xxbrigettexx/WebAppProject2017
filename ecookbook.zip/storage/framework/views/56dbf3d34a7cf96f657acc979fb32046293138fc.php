<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="/css/style3.css">
		<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.css">
</head>
<body>

		<div class="box">
		<div class="container">
			<ul class="nav nav-bar nav">
			    <li><a href="/">HOME</a></li>
			    <li><a href="/comment">COMMENTS</a></li>
			    <li><a href="/menu">MENU</a></li>
			   	<li><a href="/comment-show">SHOW COMMENTS</a></li>
			</ul>
		</div>

		<div class="container">
			<div class="pic">
				<img src="/pictures/Captur5e.PNG">
				<img src="/pictures/Capture.PNG">
				<img src="/pictures/Capture2.PNG">
				<img src="/pictures/Capture3.PNG">
				<img src="/pictures/Capture4.PNG">
				<img src="/pictures/Capture6.PNG">
			</div>
		</div>
		<div>
			<p Class="FONT3">TOP FOOD MEAL</p>
			<h6 Class="pic2">FILIPINO FOODS</h6>
			<p class="adobo">ADOBO</p>
			<p class="f6">Adobo is one of the most popular Filipino dishes<br>
			 and is considered unofficially by many as the national dish.<br> It usually consists of pork or chicken,<br> sometimes both, stewed or braised in a sauce usually made from vinegar,<br> cooking oil, garlic, bay leaf, peppercorns, and soy sauce.</p>
		</div>
		

</body>
</html>